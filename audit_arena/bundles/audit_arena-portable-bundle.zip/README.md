# audit_arena — portable bundle (v2.0.0-portable)

A reusable, **project-agnostic** adversarial-audit engine for IBM Data projects. Drop `audit_arena/`
into any repo, pick (or write) a contract profile, and get an executable, gated audit with a
`courtroom.html` dashboard.

```
audit_arena/
├── bin/            arena.py (engine) · llm.sh (Mode-B router) · pre-merge-hook.sh (gate)
├── contract/       contract.v1.json   ← the ACTIVE profile (default: watsonx-data)
├── profiles/       hcd · watsonx-data · _template   (+ gen_profiles.py to author contracts as dicts)
├── prompts/        the 9 role charters (project-agnostic; domain comes from the contract)
├── integration/    Makefile.snippet · ci.github.yml · gitignore.snippet
├── tests/          test_bundle.py  (offline engine self-tests — `pytest audit_arena/tests/`)
├── docs/           DESIGN*.md (rationale, from the HCD origin)
├── README.md  ·  ADAPTATION.md  ·  INSTALL.md
```

## Start here

1. **[audit_arena/INSTALL.md](audit_arena/INSTALL.md)** — drop the engine into your repo, wire Make + CI.
2. **[audit_arena/ADAPTATION.md](audit_arena/ADAPTATION.md)** — retarget to your product (contract
   schema, the declarative check vocabulary, a worked watsonx.data walkthrough).
3. **[audit_arena/README.md](audit_arena/README.md)** — engine overview, subcommands, honesty model.

## 30-second sanity check

```bash
python3 audit_arena/bin/arena.py contract        # active profile validates (watsonx-data)
python3 -m pytest audit_arena/tests/ -q           # 9 offline engine self-tests
ARENA_PROFILE=hcd python3 audit_arena/bin/arena.py contract   # the reference profile
```

## What's already adapted for watsonx.data

The **watsonx-data** profile (the active default) ships a realistic starter for Presto/Trino +
Iceberg + object storage: 7 invariants, an Oracle battery (offline + live), a version-fact denylist,
the Lakehouse-engineer judge lens, and a product-specific forbidden-patterns snippet. Every check is
a *shape* with `TODO` markers — point them at your deployment per ADAPTATION.md §5. It is the only
profile marked `"status": "starter"`; `hcd` is the complete reference.

> Engine refactor note: the original engine hardcoded its check battery in Python. This bundle makes
> the battery **contract data**, so retargeting needs no Python edits. It also fixes a portability bug
> found by the arena's own audit (`llm.sh` aborted under bash 3.2 when `~/.secrets.env` was absent).
