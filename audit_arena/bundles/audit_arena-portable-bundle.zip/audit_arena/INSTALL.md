# INSTALL — dropping the arena into a repo

## 0. Requirements

- **Python 3.11+** (stdlib only — no pip install). `pyyaml` is only needed by config dup-key checks
  that use it; install per project if your contract's checks call it.
- `git` (for `verify-fix`/forge worktree isolation, manifest provenance).
- Optional: `shellcheck`, `docker`/`docker compose`, and whatever CLIs your contract's Oracle checks
  invoke (e.g. `trino`, `mc`, `cqlsh`).

## 1. Copy the engine in

```bash
unzip audit_arena-bundle.zip            # yields audit_arena/
cp -R audit_arena /path/to/your-repo/   # the engine expects to live at <repo-root>/audit_arena/
```

The engine derives the repo root as the parent of `audit_arena/`. Nothing else is assumed about your
layout — the Oracle checks come from the contract.

## 2. Pick / build a profile

```bash
cd /path/to/your-repo
# fastest start: activate the watsonx.data starter, then edit it (see ADAPTATION.md)
cp audit_arena/profiles/watsonx-data/contract.v1.json audit_arena/contract/contract.v1.json
python3 audit_arena/bin/arena.py contract        # CONTRACT OK …
```

For a brand-new product: `cp -R audit_arena/profiles/_template audit_arena/profiles/<slug>`, fill it
(ADAPTATION.md §1–5), then activate.

## 3. Wire the Make targets (optional)

Append [`integration/Makefile.snippet`](integration/Makefile.snippet) to your `Makefile`:

```bash
cat audit_arena/integration/Makefile.snippet >> Makefile
make audit                 # full pipeline + courtroom.html + gate
make audit-install-hook    # install the pre-push gate
```

## 4. Wire CI (optional)

Add the [`integration/ci.github.yml`](integration/ci.github.yml) job to your GitHub Actions workflow
(or copy it as a standalone workflow). It runs the deterministic gate and uploads the manifest +
`courtroom.html` as artifacts. The same gate is the local pre-push hook.

## 5. Ignore generated artefacts

Append [`integration/gitignore.snippet`](integration/gitignore.snippet) to your `.gitignore`. Tracked:
the contract, profiles, prompts, and any seed `state/findings_r1.json` you choose to commit.
Generated (ignore): `courtroom.html`, `state/oracle_r*.json`, `state/invariants_r*.json`,
`state/manifest_r*.json`, `state/REPO_MAP.md`, etc.

## 6. (Optional) the LLM tribunal

The deterministic gate needs no LLM. The advisory tribunal does:

- **Mode A** — dispatch the role charters (`prompts/`) to in-session model subagents (diversity of
  model family is the anti-collusion mechanism).
- **Mode B** — `bin/llm.sh <role> <prompt>` routes to an external vendor (glm/gemini/anthropic/
  openai-compatible). **Egress is opt-in**: requires `ARENA_MODE_B=1` and a provider key, else it
  abstains (exit 2) and you fall back to Mode A. Put keys in `~/.secrets.env`.

## Smoke test the install

```bash
python3 -m pytest audit_arena/tests/ -q     # engine self-tests (offline, no system needed)
python3 audit_arena/bin/arena.py contract
python3 audit_arena/bin/arena.py oracle && python3 audit_arena/bin/arena.py gate
```
