# audit_arena — a portable adversarial-audit engine

A self-contained, **project-agnostic** audit engine: a 4-role tribunal
(**Prosecutor / Defender / Judge / Oracle**) wrapped around a deterministic, executable ground-truth
battery. It turns "trust me, this is correct" into "run it and see." Originally built for and
dogfooded against an IBM HCD 2.0 / Cassandra 5.0 demo repo; this bundle is the **decoupled engine**
plus three profiles (`hcd`, `watsonx-data`, `_template`).

The differentiator is the **Oracle**: claims have a *runnable* check (SQL/CLI/lint/config-merge/
dup-key), so findings are **executably adjudicated**, not merely argued. The LLM tribunal is
*advisory*; the deterministic Oracle + invariants are what **block** a merge.

## What is and isn't in the engine

- **Generic plumbing (reuse as-is):** the contract spine, invariants runner, Oracle battery runner,
  provenance manifest (git SHA + tool versions + Merkle `audit_root`), per-finding lineage, honesty
  reconciler, advisory scored panel, multi-vendor panel, generative `verify-fix` / forge (throwaway
  git worktree), the `gate`, and the `courtroom.html` render + pupitre console.
- **Everything domain-specific is DATA** in the active contract (`contract/contract.v1.json`):
  the invariants, the Oracle's offline/live checks, the version-fact denylist, the dashboard title,
  and the judge's domain lens. **Retargeting = editing one JSON file. No Python edits.**

## Quick start (against the repo this folder lives in)

```bash
# pick a profile (writes the active contract slot)
python3 audit_arena/bin/arena.py contract            # validate the active contract
ARENA_PROFILE=watsonx-data python3 audit_arena/bin/arena.py contract

# the deterministic pipeline (this is what `make audit` chains):
python3 audit_arena/bin/arena.py repomap
python3 audit_arena/bin/arena.py oracle              # run the contract's check battery
python3 audit_arena/bin/arena.py invariants          # evaluate the Definition-of-Done
python3 audit_arena/bin/arena.py lineage
python3 audit_arena/bin/arena.py manifest
python3 audit_arena/bin/arena.py reconcile
python3 audit_arena/bin/arena.py render              # -> audit_arena/courtroom.html
python3 audit_arena/bin/arena.py gate                # exit 1 if any FAIL (DEFERRED/TIMEOUT never block)
```

## Selecting a profile

The active contract is resolved in this order (first match wins):

1. `ARENA_CONTRACT=/path/to/contract.json` — explicit file
2. `ARENA_PROFILE=<name>` — `audit_arena/profiles/<name>/contract.v1.json`
3. `audit_arena/contract/contract.v1.json` — the default "active" slot

To make a profile the default, copy it into the active slot:

```bash
cp audit_arena/profiles/watsonx-data/contract.v1.json audit_arena/contract/contract.v1.json
```

## Profiles shipped

| Profile | Status | What it audits |
|---|---|---|
| `hcd` | reference (complete) | IBM HCD 2.0 / Cassandra 5.0 — the original, faithfully ported to contract data |
| `watsonx-data` | **starter** | IBM watsonx.data — Presto/Trino + Iceberg + object storage (edit to your repo) |
| `_template` | blank | copy to `profiles/<your-product>/` and fill the `<PLACEHOLDERS>` |

## Status model (honest deferral)

`PASS` (green) · `FAIL` (red, **blocks** the gate) · `DEFERRED` (amber — a live check with no running
system; **never blocks**, and a prior live PASS is surfaced green with its timestamp via
`state/last_live.json`) · `TIMEOUT` (amber — a check that couldn't finish, usually CPU contention from
a running system; inconclusive, non-blocking).

## Retargeting to a new product

See **[ADAPTATION.md](ADAPTATION.md)** — the contract schema, the declarative check vocabulary, and a
worked walkthrough of the watsonx.data starter. See **[INSTALL.md](INSTALL.md)** to drop the engine
into a repo and wire the Make targets + CI gate.

The design rationale (Oracle primacy, honesty guardrails, lineage, remediation, self-hardening) is in
[`docs/DESIGN*.md`](docs/) — written for the HCD origin, but the mechanics are the engine's.
