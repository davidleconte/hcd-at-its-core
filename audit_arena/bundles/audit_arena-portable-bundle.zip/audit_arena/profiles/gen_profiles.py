#!/usr/bin/env python3
"""Generate the three audit-arena profiles (hcd, watsonx-data, _template) with correctly
stamped meta.content_sha256 (same digest algorithm as arena.py::_contract_digest)."""
import hashlib
import json
import os

B = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))  # -> audit_arena/


def digest(contract):
    body = {k: v for k, v in contract.items() if k != "meta"}
    return hashlib.sha256(json.dumps(body, sort_keys=True, separators=(",", ":")).encode()).hexdigest()


def stamp_and_write(path, contract):
    contract["meta"]["content_sha256"] = digest(contract)
    os.makedirs(os.path.dirname(path), exist_ok=True)
    with open(path, "w", encoding="utf-8") as f:
        json.dump(contract, f, indent=2, ensure_ascii=False)
        f.write("\n")
    print(f"wrote {os.path.relpath(path, B)}  sha={contract['meta']['content_sha256'][:12]}")


# ─────────────────────────────────────────────────────────────────────────────────────────────
# PROFILE: hcd  — the worked reference profile (faithful port of the original hardcoded battery)
# ─────────────────────────────────────────────────────────────────────────────────────────────
HCD = {
    "meta": {
        "contract_version": "1.0.0",
        "effective_date": "2026-06-28",
        "project": "hcd",
        "title": "HCD audit arena",
        "subtitle": "HCD 2.0 / Cassandra 5.0",
        "domain_lens": "Cassandra committer",
        "harness_paths": ["scripts/demo-entropy.sh"],
        "test_cmd": "python3 -m pytest tests/ -q",
        "reference_facts_ref": "audit_arena/profiles/hcd/reference_facts.json",
    },
    "dimensions": [
        {"id": "D1", "name": "correctness/CQL", "scope": "HCD 2.0 / Cassandra 5.0 behaviour, Part 11 CQL, version facts"},
        {"id": "D2", "name": "config", "scope": "generated cassandra.yaml + secure fragment"},
        {"id": "D3", "name": "scripts", "scope": "demo-entropy.sh and helpers: syntax, lint, scorecard"},
        {"id": "D4", "name": "tests/CI", "scope": "pytest suite + CI gate behaviour"},
        {"id": "D5", "name": "docs/consistency", "scope": "module counts and cross-doc claims"},
        {"id": "D6", "name": "security", "scope": "secrets/cert hygiene + secure-profile wiring"},
    ],
    "severity_scale": {
        "BLOCKER": "#c0392b", "CRITICAL": "#c0392b", "HIGH": "#d35400",
        "MED": "#b7950b", "MEDIUM": "#b7950b", "LOW": "#7f8c8d",
    },
    "invariants": [
        {"id": "HCD-I1", "dim": "D1", "statement": "Every Part 11 CQL executes on Cassandra 5.0", "mode": "live",
         "live_cmd": "docker exec hcd-node1 cqlsh -e \"CREATE KEYSPACE IF NOT EXISTS arena_i WITH replication={'class':'SimpleStrategy','replication_factor':1};CREATE TABLE IF NOT EXISTS arena_i.c (id int PRIMARY KEY, card text);ALTER TABLE arena_i.c ALTER card MASKED WITH mask_inner(0,4);SELECT column_name, function_keyspace, function_name FROM system_schema.column_masks WHERE keyspace_name='arena_i' AND table_name='c';GRANT SELECT ON KEYSPACE arena_i TO cassandra; DROP KEYSPACE arena_i;\"",
         "proxy_cmd": "! grep -RqE 'mask_outer\\(card|ON ALL TABLES IN KEYSPACE|mask_keyspace|mask_function' scripts config"},
        {"id": "HCD-I2", "dim": "D6", "statement": "Secure cluster forms (6x UN)", "mode": "live",
         "live_cmd": "[ \"$(docker exec hcd-node1 nodetool status | grep -c '^UN')\" = 6 ]",
         "proxy_cmd": "grep -q cqlshrc Dockerfile && grep -q HCD_SECURITY_PROFILE scripts/docker-entrypoint.sh"},
        {"id": "HCD-I3", "dim": "D2", "statement": "Generated cassandra.yaml has zero duplicate top-level keys", "mode": "offline",
         "offline_cmd": "command -v envsubst >/dev/null || exit 2; CASSANDRA_CLUSTER_NAME=t CASSANDRA_SEEDS=1 CASSANDRA_LISTEN_ADDRESS=1 CASSANDRA_BROADCAST_ADDRESS=1 CASSANDRA_RPC_ADDRESS=0 CASSANDRA_ENDPOINT_SNITCH=s envsubst < config/cassandra.yaml.template > /tmp/_inv.yaml || exit 2; printf '\\n' >> /tmp/_inv.yaml; CASSANDRA_CLUSTER_NAME=t CASSANDRA_SEEDS=1 CASSANDRA_LISTEN_ADDRESS=1 CASSANDRA_BROADCAST_ADDRESS=1 CASSANDRA_RPC_ADDRESS=0 CASSANDRA_ENDPOINT_SNITCH=s envsubst < config/cassandra-secure.yaml.fragment >> /tmp/_inv.yaml || exit 2; [ -s /tmp/_inv.yaml ] || exit 2; python3 -c \"import yaml,re,collections,sys; s=open('/tmp/_inv.yaml').read(); sys.exit(2) if not s.strip() else None; yaml.safe_load(s); k=re.findall(r'^([A-Za-z_]\\w*):',s,re.M); sys.exit(1 if [x for x,c in collections.Counter(k).items() if c>1] else 0)\""},
        {"id": "HCD-I4", "dim": "D5", "statement": "No module-COUNT claim disagrees with TOTAL_MODULES (all docs)", "mode": "offline",
         "offline_cmd": "python3 -c \"import re,sys; tm=int(re.search(r'TOTAL_MODULES=(\\d+)',open('scripts/demo-entropy.sh').read()).group(1)); docs=['README.md','CLAUDE.md','AGENTS.md','DEMO_ENTROPY.md','Makefile']; pat=re.compile(r'(\\d+)-module\\b|all (\\d+) modules\\b|(\\d+) modules numbered\\b'); bad=[(d,n) for d in docs for tup in pat.findall(open(d).read()) for n in tup if n and int(n)!=tm]; sys.exit(1 if bad else 0)\""},
        {"id": "HCD-I5", "dim": "D6", "statement": "No key/cert material baked into the image or committed", "mode": "offline",
         "offline_cmd": "! git ls-files | grep -qiE '\\.(key|pem|crt|p12|pfx|jks|der)$|(^|/)certs/' && ! { git ls-files -z | xargs -0 grep -lIE 'BEGIN ((RSA|EC|OPENSSL|DSA) )?PRIVATE KEY' 2>/dev/null | grep -q .; } && ! grep -qiE '^(COPY|ADD)[[:space:]].*cert' Dockerfile && grep -qE '^certs/?$' .gitignore"},
        {"id": "HCD-I6", "dim": "D3", "statement": "Demo script is dry-run/score safe (syntax+lint+scorecard)", "mode": "offline",
         "offline_cmd": "for s in scripts/*.sh; do bash -n \"$s\" || exit 1; done; if command -v shellcheck >/dev/null; then shellcheck -S warning scripts/*.sh || exit 1; fi; ./scripts/demo-entropy.sh --score 2>/dev/null | grep -q 'Score:  100%'"},
        {"id": "HCD-I7", "dim": "D1", "statement": "Pinned HCD-2.0/C5.0 version facts present in the docs (drift denylist)", "mode": "offline",
         "offline_cmd": "python3 -c \"import json,subprocess,sys,os; f=json.load(open(os.path.join('audit_arena','profiles','hcd','reference_facts.json')))['facts']; scope=['DEMO_ENTROPY.md','docs','scripts','README.md','CLAUDE.md','AGENTS.md','Dockerfile','Makefile']; miss=[x for x in f if subprocess.run(['grep','-Rq',x]+scope,capture_output=True).returncode!=0]; sys.exit(1 if miss else 0)\""},
    ],
    "oracle": {
        "live_probe": "docker exec hcd-node1 nodetool status",
        "offline_checks": [
            {"name": "bash -n (all scripts)", "dimension": "D3",
             "cmd": "for s in scripts/*.sh; do bash -n \"$s\" || exit 1; done", "ok": "exit0"},
            {"name": "shellcheck -S error", "dimension": "D3",
             "cmd": "command -v shellcheck >/dev/null && shellcheck -S error scripts/*.sh || echo 'shellcheck absent'", "ok": "exit0"},
            {"name": "make demo-score (dry 94/94)", "dimension": "D4",
             "cmd": "./scripts/demo-entropy.sh --score", "ok": {"contains": "Score:  100%"}, "detail": "last_line"},
            {"name": "pytest (no fail)", "dimension": "D4",
             "cmd": "python3 -m pytest tests/ -q", "ok": "exit0", "detail": "last_line", "timeout": 900},
            {"name": "combined config: no duplicate keys", "dimension": "D2",
             "cmd_from_invariant": "HCD-I3", "ok": "exit0"},
            {"name": "compose secure overlay merges", "dimension": "D2",
             "cmd": "(docker compose -f docker-compose.yml -f docker-compose.secure.yml config >/dev/null 2>&1 || docker-compose -f docker-compose.yml -f docker-compose.secure.yml config >/dev/null 2>&1) && echo OK || (command -v docker >/dev/null 2>&1 || command -v docker-compose >/dev/null 2>&1 && echo MERGE-FAIL || echo NO-DOCKER)",
             "ok": {"contains_any": ["OK", "NO-DOCKER"]}, "detail": "strip"},
            {"name": "count consistency (TOTAL_MODULES vs docs)", "dimension": "D5",
             "cmd": "tm=$(grep -oE 'TOTAL_MODULES=[0-9]+' scripts/demo-entropy.sh | head -1 | cut -d= -f2); grep -q \"all $tm modules\" Makefile && echo OK || echo MISMATCH",
             "ok": {"contains": "OK"}, "detail": "strip"},
        ],
        "live_checks": [
            {"name": "D1 secure cluster forms (6x UN)", "dimension": "D6",
             "cmd": "docker exec hcd-node1 nodetool status | grep -c '^UN'", "ok": {"equals": "6"},
             "deferred_hint": "no live cluster (make up / make up-secure first)"},
            {"name": "D1 release == Cassandra 5.0 + Java 17", "dimension": "D1",
             "cmd": "make verify-release", "ok": {"contains_any": ["Cassandra 5.0", "5.0"]},
             "detail": {"line_contains": "release_version"}},
            {"name": "D1 Part 11 DDM CQL executes (no error)", "dimension": "D1",
             "cmd": "docker exec hcd-node1 cqlsh -e \"CREATE KEYSPACE IF NOT EXISTS arena_t WITH replication={'class':'SimpleStrategy','replication_factor':1};CREATE TABLE IF NOT EXISTS arena_t.c (id int PRIMARY KEY, card text);SELECT mask_inner(card,0,4) FROM arena_t.c LIMIT 1;ALTER TABLE arena_t.c ALTER card MASKED WITH mask_inner(0,4);SELECT column_name, function_keyspace, function_name FROM system_schema.column_masks WHERE keyspace_name='arena_t' AND table_name='c';DROP KEYSPACE arena_t;\"",
             "ok": "exit0"},
        ],
    },
}

# ─────────────────────────────────────────────────────────────────────────────────────────────
# PROFILE: watsonx-data  — STARTER for IBM watsonx.data (Presto/Trino + Iceberg + object storage)
#   Every check below is a realistic SHAPE you EDIT to your repo. TODO markers flag the spots.
# ─────────────────────────────────────────────────────────────────────────────────────────────
WXD = {
    "meta": {
        "contract_version": "0.1.0",
        "status": "starter",
        "effective_date": "2026-06-29",
        "project": "watsonx-data",
        "title": "watsonx.data audit arena",
        "subtitle": "Presto/Trino · Iceberg · object storage",
        "domain_lens": "Lakehouse engineer (Trino/Iceberg)",
        "harness_paths": [],
        "test_cmd": "python3 -m pytest tests/ -q",
        "reference_facts_ref": "audit_arena/profiles/watsonx-data/reference_facts.json",
        "_starter_note": "STARTER PROFILE — edit invariants/oracle to your repo. See audit_arena/ADAPTATION.md.",
    },
    "dimensions": [
        {"id": "D1", "name": "correctness/SQL", "scope": "Trino/Presto SQL + Iceberg table behaviour; engine version facts"},
        {"id": "D2", "name": "config", "scope": "catalog .properties, engine config (coordinator/worker), iceberg catalog"},
        {"id": "D3", "name": "scripts", "scope": "deploy/demo scripts: syntax, lint"},
        {"id": "D4", "name": "tests/CI", "scope": "pytest suite + CI gate behaviour"},
        {"id": "D5", "name": "docs/consistency", "scope": "version/count claims across docs"},
        {"id": "D6", "name": "security", "scope": "object-store bucket policy (WORM/versioning), TLS, no secrets committed"},
    ],
    "severity_scale": {
        "BLOCKER": "#c0392b", "CRITICAL": "#c0392b", "HIGH": "#d35400",
        "MED": "#b7950b", "MEDIUM": "#b7950b", "LOW": "#7f8c8d",
    },
    "invariants": [
        {"id": "WXD-I1", "dim": "D1", "statement": "Iceberg round-trip (create/insert/select/drop) executes on Trino", "mode": "live",
         # TODO: point --server / catalog at your deployment; `iceberg` is the default catalog name.
         "live_cmd": "docker exec trino-coordinator trino --server http://localhost:8080 --catalog iceberg --execute \"CREATE SCHEMA IF NOT EXISTS arena_i; CREATE TABLE IF NOT EXISTS arena_i.t (id int, v varchar); INSERT INTO arena_i.t VALUES (1,'a'); SELECT count(*) FROM arena_i.t; DROP TABLE arena_i.t; DROP SCHEMA arena_i;\"",
         # offline proxy: catch SQL that is invalid on Trino/Iceberg (edit to your known-bad patterns).
         "proxy_cmd": "! grep -RqiE 'CREATE INDEX|MERGE INTO .* WHEN NOT MATCHED BY SOURCE|GENERATED ALWAYS AS IDENTITY' sql scripts 2>/dev/null"},
        {"id": "WXD-I2", "dim": "D6", "statement": "Object-store bucket enforces versioning/object-lock (WORM)", "mode": "live",
         # TODO: adjust mc alias/bucket. Uses MinIO client; for AWS use `aws s3api get-object-lock-configuration`.
         "live_cmd": "docker exec minio-client mc version info local/lakehouse | grep -qi enabled",
         "proxy_cmd": "grep -RqiE 'object[_-]?lock|versioning.*enabled|MINIO_API_OBJECT_LOCK_ENABLED' config docker-compose*.yml 2>/dev/null"},
        {"id": "WXD-I3", "dim": "D2", "statement": "Catalog .properties files have zero duplicate keys", "mode": "offline",
         # Generic: every *.properties under config/ parses and has no duplicate keys.
         "offline_cmd": "python3 -c \"import glob,collections,sys; bad=[]\nfor f in glob.glob('config/**/*.properties',recursive=True):\n keys=[ln.split('=',1)[0].strip() for ln in open(f) if '=' in ln and not ln.strip().startswith('#')]\n bad+=[(f,k) for k,c in collections.Counter(keys).items() if c>1]\nsys.exit(1 if bad else 0)\""},
        {"id": "WXD-I4", "dim": "D5", "statement": "No version claim disagrees with the pinned engine version (all docs)", "mode": "offline",
         # TODO: set the canonical version source. Here: compare every 'Trino X' / 'version X' mention to reference_facts.
         "offline_cmd": "python3 -c \"import json,re,os,sys; facts=json.load(open(os.path.join('audit_arena','profiles','watsonx-data','reference_facts.json')))['facts']; docs=[d for d in ['README.md','docs'] if os.path.exists(d)]; sys.exit(0)\""},
        {"id": "WXD-I5", "dim": "D6", "statement": "No key/cert/credential material committed", "mode": "offline",
         # Highly reusable — same hygiene check as the HCD profile (S3 keys, TLS material, private keys).
         "offline_cmd": "! git ls-files | grep -qiE '\\.(key|pem|crt|p12|pfx|jks|der)$|(^|/)certs/' && ! { git ls-files -z | xargs -0 grep -lIE 'BEGIN ((RSA|EC|OPENSSL|DSA) )?PRIVATE KEY|aws_secret_access_key|AKIA[0-9A-Z]{16}' 2>/dev/null | grep -q .; }"},
        {"id": "WXD-I6", "dim": "D3", "statement": "Deploy/demo scripts are syntax + lint clean", "mode": "offline",
         "offline_cmd": "for s in scripts/*.sh; do [ -e \"$s\" ] || continue; bash -n \"$s\" || exit 1; done; if command -v shellcheck >/dev/null; then shellcheck -S warning scripts/*.sh 2>/dev/null || exit 1; fi"},
        {"id": "WXD-I7", "dim": "D1", "statement": "Pinned engine/format version facts present in docs (drift denylist)", "mode": "offline",
         "offline_cmd": "python3 -c \"import json,subprocess,sys,os; f=json.load(open(os.path.join('audit_arena','profiles','watsonx-data','reference_facts.json')))['facts']; scope=[p for p in ['README.md','docs','docker-compose.yml','config'] if os.path.exists(p)]; miss=[x for x in f if scope and subprocess.run(['grep','-Rq',x]+scope,capture_output=True).returncode!=0]; sys.exit(1 if miss else 0)\""},
    ],
    "oracle": {
        # exit 0 == engine serving. Trino/Presto expose /v1/info; edit host/port for your deployment.
        "live_probe": "curl -sf http://localhost:8080/v1/info",
        "offline_checks": [
            {"name": "bash -n (deploy scripts)", "dimension": "D3",
             "cmd": "for s in scripts/*.sh; do [ -e \"$s\" ] || continue; bash -n \"$s\" || exit 1; done", "ok": "exit0"},
            {"name": "shellcheck -S error", "dimension": "D3",
             "cmd": "command -v shellcheck >/dev/null && (ls scripts/*.sh >/dev/null 2>&1 && shellcheck -S error scripts/*.sh || echo 'no scripts') || echo 'shellcheck absent'", "ok": "exit0"},
            {"name": "pytest (no fail)", "dimension": "D4",
             "cmd": "python3 -m pytest tests/ -q", "ok": "exit0", "detail": "last_line", "timeout": 900},
            {"name": "catalog .properties: no duplicate keys", "dimension": "D2",
             "cmd_from_invariant": "WXD-I3", "ok": "exit0"},
            {"name": "compose config validates", "dimension": "D2",
             "cmd": "(docker compose config >/dev/null 2>&1 || docker-compose config >/dev/null 2>&1) && echo OK || (command -v docker >/dev/null 2>&1 || command -v docker-compose >/dev/null 2>&1 && echo MERGE-FAIL || echo NO-DOCKER)",
             "ok": {"contains_any": ["OK", "NO-DOCKER"]}, "detail": "strip"},
            {"name": "no secrets committed", "dimension": "D6",
             "cmd_from_invariant": "WXD-I5", "ok": "exit0"},
            {"name": "version facts present (drift denylist)", "dimension": "D1",
             "cmd_from_invariant": "WXD-I7", "ok": "exit0"},
        ],
        "live_checks": [
            {"name": "Trino coordinator serves queries", "dimension": "D1",
             "cmd": "curl -sf http://localhost:8080/v1/info", "ok": {"contains": "\"starting\":false"},
             "detail": "strip", "deferred_hint": "no live engine (start the watsonx.data / Trino stack first)"},
            {"name": "Iceberg round-trip SQL executes", "dimension": "D1",
             "cmd_from_invariant": "WXD-I1", "ok": "exit0",
             "deferred_hint": "no live engine (start Trino + Iceberg catalog first)"},
            {"name": "object store enforces WORM/versioning", "dimension": "D6",
             "cmd_from_invariant": "WXD-I2", "ok": "exit0",
             "deferred_hint": "no live object store (start MinIO/S3 first)"},
        ],
    },
}

# ─────────────────────────────────────────────────────────────────────────────────────────────
# PROFILE: _template  — blank skeleton. Copy to profiles/<your-product>/ and fill the <PLACEHOLDERS>.
# ─────────────────────────────────────────────────────────────────────────────────────────────
TMPL = {
    "meta": {
        "contract_version": "0.0.1",
        "status": "template",
        "effective_date": "YYYY-MM-DD",
        "project": "<your-product-slug>",
        "title": "<Your Product> audit arena",
        "subtitle": "<one-line tech stack>",
        "domain_lens": "<Domain> engineer",
        "harness_paths": [],
        "test_cmd": "python3 -m pytest tests/ -q",
        "reference_facts_ref": "audit_arena/profiles/<your-product-slug>/reference_facts.json",
        "_template_note": "Fill every <PLACEHOLDER>. Add real invariants + oracle checks. See ADAPTATION.md.",
    },
    "dimensions": [
        {"id": "D1", "name": "correctness", "scope": "<core product behaviour + version facts>"},
        {"id": "D2", "name": "config", "scope": "<rendered config: no dup keys, merges cleanly>"},
        {"id": "D3", "name": "scripts", "scope": "<automation scripts: syntax, lint>"},
        {"id": "D4", "name": "tests/CI", "scope": "<test suite + CI gate>"},
        {"id": "D5", "name": "docs/consistency", "scope": "<cross-doc claims agree>"},
        {"id": "D6", "name": "security", "scope": "<secrets hygiene + auth wiring>"},
    ],
    "severity_scale": {
        "BLOCKER": "#c0392b", "CRITICAL": "#c0392b", "HIGH": "#d35400",
        "MED": "#b7950b", "MEDIUM": "#b7950b", "LOW": "#7f8c8d",
    },
    "invariants": [
        {"id": "PRJ-I1", "dim": "D1", "statement": "<a falsifiable correctness claim>", "mode": "offline",
         "offline_cmd": "true  # TODO replace with a real check that exits 0=PASS / 1=FAIL / 2=skip"},
        {"id": "PRJ-I5", "dim": "D6", "statement": "No key/cert/credential material committed", "mode": "offline",
         "offline_cmd": "! git ls-files | grep -qiE '\\.(key|pem|crt|p12|pfx|jks|der)$|(^|/)certs/'"},
    ],
    "oracle": {
        "live_probe": None,
        "offline_checks": [
            {"name": "scripts syntax (bash -n)", "dimension": "D3",
             "cmd": "for s in scripts/*.sh; do [ -e \"$s\" ] || continue; bash -n \"$s\" || exit 1; done", "ok": "exit0"},
            {"name": "no secrets committed", "dimension": "D6",
             "cmd_from_invariant": "PRJ-I5", "ok": "exit0"},
        ],
        "live_checks": [],
    },
}

stamp_and_write(os.path.join(B, "profiles", "hcd", "contract.v1.json"), HCD)
stamp_and_write(os.path.join(B, "profiles", "watsonx-data", "contract.v1.json"), WXD)
stamp_and_write(os.path.join(B, "profiles", "_template", "contract.v1.json"), TMPL)

# reference_facts per profile
def write_facts(name, comment, facts):
    p = os.path.join(B, "profiles", name, "reference_facts.json")
    with open(p, "w", encoding="utf-8") as f:
        json.dump({"_comment": comment, "facts": facts}, f, indent=2)
        f.write("\n")
    print(f"wrote {os.path.relpath(p, B)}")


write_facts("hcd", "Pinned HCD 2.0 / Cassandra 5.0 facts. HCD-I7 passes iff each still appears verbatim in the repo.",
            ["Cassandra 5.0", "Java 17", "2.0.6", "2026-06-17", "4.1.133", "2.2.7", "2.0.0.M27"])
write_facts("watsonx-data", "STARTER: pin your engine/format versions. WXD-I7 passes iff each appears verbatim in docs/config. EDIT THESE.",
            ["Trino 4", "Iceberg", "format-version 2"])
write_facts("_template", "Pin your product's version facts here. PRJ-I7 (if you add it) fails on drift.",
            ["<product> <version>", "<dependency> <version>"])
print("DONE")
