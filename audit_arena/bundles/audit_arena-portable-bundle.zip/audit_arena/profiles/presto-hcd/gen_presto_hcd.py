#!/usr/bin/env python3
"""Generate the `presto-hcd` audit profile, concretized against the IBM/presto-hcd cookbook repo
(watsonx.data + DataStax HCD 1.2 + Apache Iceberg; Presto CLI 0.286 @ http://localhost:8080).
Stamps meta.content_sha256 with the same digest algorithm as arena.py::_contract_digest."""
import hashlib
import json
import os

HERE = os.path.dirname(os.path.abspath(__file__))            # …/audit_arena/profiles/presto-hcd


def digest(c):
    body = {k: v for k, v in c.items() if k != "meta"}
    return hashlib.sha256(json.dumps(body, sort_keys=True, separators=(",", ":")).encode()).hexdigest()


CONTRACT = {
    "meta": {
        "contract_version": "1.0.0",
        "effective_date": "2026-06-29",
        "project": "presto-hcd",
        "title": "presto-hcd cookbook audit arena",
        "subtitle": "watsonx.data · Presto 0.286 · DataStax HCD 1.2 · Apache Iceberg",
        "domain_lens": "Cookbook / Presto SQL reviewer",
        "harness_paths": [],
        "test_cmd": "python3 -m pytest tests/ -q",
        "reference_facts_ref": "audit_arena/profiles/presto-hcd/reference_facts.json",
        "notes": "Run inside the repo venv (`source scripts/ensure_venv.sh`) so python3 has pytest+ruff, "
                 "matching the repo's own Makefile. Set PRESTO_SERVER to override http://localhost:8080.",
    },
    "dimensions": [
        {"id": "D1", "name": "correctness/SQL", "scope": "cookbook DDL/query validity on Presto 0.286 / Iceberg / HCD 1.2; pinned version facts"},
        {"id": "D2", "name": "docs/build", "scope": "MkDocs version sync (cookbook/VERSION -> mkdocs.yml), implementation matrix"},
        {"id": "D3", "name": "scripts", "scope": "scripts/ + cookbook/scripts/: bash -n, shellcheck, ruff"},
        {"id": "D4", "name": "tests/CI", "scope": "pytest suite (tests/)"},
        {"id": "D5", "name": "release-integrity", "scope": "release lock (sha256 + bundle manifest) in sync; single-source version"},
        {"id": "D6", "name": "security", "scope": "no private keys / secrets committed (detect-private-key parity)"},
    ],
    "severity_scale": {
        "BLOCKER": "#c0392b", "CRITICAL": "#c0392b", "HIGH": "#d35400",
        "MED": "#b7950b", "MEDIUM": "#b7950b", "LOW": "#7f8c8d",
    },
    "invariants": [
        {"id": "PHC-I1", "dim": "D1", "statement": "A Presto query round-trip executes against the live engine", "mode": "live",
         "live_cmd": "java -jar presto-cli.jar --server \"${PRESTO_SERVER:-http://localhost:8080}\" --execute \"SELECT 1\" >/dev/null",
         # offline proxy: the demo-query gate's own dry-run must succeed (proves the runbook/query wiring
         # is well-formed without a live engine). Can DEMOTE to FAIL on broken wiring; never CONFIRM.
         "proxy_cmd": "bash scripts/validation/run_live_release_gate.sh --dry-run >/dev/null 2>&1"},
        {"id": "PHC-I2", "dim": "D5", "statement": "Release lock (sha256 + bundle manifest) honours its contract", "mode": "offline",
         "offline_cmd": "python3 -m pytest tests/test_release_lock_contract.py -q >/dev/null 2>&1"},
        {"id": "PHC-I3", "dim": "D2", "statement": "MkDocs version equals cookbook/VERSION (single source)", "mode": "offline",
         "offline_cmd": "v=$(tr -d '[:space:]' < cookbook/VERSION); grep -q \"version: \\\"$v\\\"\" cookbook/mkdocs.yml"},
        {"id": "PHC-I4", "dim": "D1", "statement": "Demo-query gate is wiring-sound (dry-run passes)", "mode": "offline",
         "offline_cmd": "bash scripts/validation/run_live_release_gate.sh --dry-run >/dev/null 2>&1"},
        {"id": "PHC-I5", "dim": "D6", "statement": "No key/cert/credential material committed", "mode": "offline",
         "offline_cmd": "! git ls-files | grep -qiE '\\.(key|pem|p12|pfx|jks|der)$|(^|/)secrets?/' && ! { git ls-files -z | xargs -0 grep -lIE 'BEGIN ((RSA|EC|OPENSSL|DSA) )?PRIVATE KEY|aws_secret_access_key|AKIA[0-9A-Z]{16}' 2>/dev/null | grep -q .; }"},
        {"id": "PHC-I6", "dim": "D3", "statement": "Shell scripts pass bash -n + shellcheck; Python passes ruff", "mode": "offline",
         "offline_cmd": "set -e; for s in $(find scripts cookbook/scripts -name '*.sh'); do bash -n \"$s\"; done; if command -v shellcheck >/dev/null; then shellcheck -S error $(find scripts cookbook/scripts -name '*.sh'); fi; if command -v ruff >/dev/null; then ruff check scripts/ cookbook/scripts/ tests/; fi"},
        {"id": "PHC-I7", "dim": "D1", "statement": "Pinned stack version facts present in docs/scripts (drift denylist)", "mode": "offline",
         "offline_cmd": "python3 -c \"import json,subprocess,sys,os; f=json.load(open(os.path.join('audit_arena','profiles','presto-hcd','reference_facts.json')))['facts']; scope=[p for p in ['README.md','cookbook/docs','cookbook/scripts','scripts'] if os.path.exists(p)]; miss=[x for x in f if subprocess.run(['grep','-Rqs',x]+scope,capture_output=True).returncode!=0]; sys.exit(1 if miss else 0)\""},
    ],
    "oracle": {
        "live_probe": "java -jar presto-cli.jar --server \"${PRESTO_SERVER:-http://localhost:8080}\" --execute \"SELECT 1\"",
        "offline_checks": [
            {"name": "scripts: bash -n + shellcheck + ruff", "dimension": "D3", "cmd_from_invariant": "PHC-I6", "ok": "exit0"},
            {"name": "pytest suite (tests/)", "dimension": "D4",
             "cmd": "python3 -m pytest tests/ -q", "ok": "exit0", "detail": "last_line", "timeout": 900},
            {"name": "demo-query gate dry-run (wiring sound)", "dimension": "D1", "cmd_from_invariant": "PHC-I4", "ok": "exit0"},
            {"name": "release-lock contract", "dimension": "D5", "cmd_from_invariant": "PHC-I2", "ok": "exit0"},
            {"name": "version single-source (mkdocs == VERSION)", "dimension": "D2", "cmd_from_invariant": "PHC-I3", "ok": "exit0"},
            {"name": "no secrets committed", "dimension": "D6", "cmd_from_invariant": "PHC-I5", "ok": "exit0"},
            {"name": "version facts present (drift denylist)", "dimension": "D1", "cmd_from_invariant": "PHC-I7", "ok": "exit0"},
        ],
        "live_checks": [
            {"name": "Presto serves SELECT 1", "dimension": "D1", "cmd_from_invariant": "PHC-I1", "ok": "exit0",
             "deferred_hint": "no live Presto at $PRESTO_SERVER (default http://localhost:8080) — start watsonx.data/Presto first"},
        ],
    },
}

CONTRACT["meta"]["content_sha256"] = digest(CONTRACT)
with open(os.path.join(HERE, "contract.v1.json"), "w", encoding="utf-8") as f:
    json.dump(CONTRACT, f, indent=2, ensure_ascii=False)
    f.write("\n")

FACTS = {
    "_comment": "Pinned presto-hcd stack facts. PHC-I7 passes iff each still appears verbatim in "
                "README.md / cookbook/docs / cookbook/scripts / scripts. A drift to a wrong version fails it.",
    "facts": ["DataStax HCD 1.2", "watsonx.data", "Apache Iceberg", "0.286"],
}
with open(os.path.join(HERE, "reference_facts.json"), "w", encoding="utf-8") as f:
    json.dump(FACTS, f, indent=2)
    f.write("\n")

print("wrote presto-hcd contract sha=", CONTRACT["meta"]["content_sha256"][:12])
