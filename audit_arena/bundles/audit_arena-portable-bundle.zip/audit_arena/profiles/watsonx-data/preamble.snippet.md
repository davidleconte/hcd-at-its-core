## watsonx.data — product-specific forbidden patterns (STARTER — edit/extend)

Append these to the engine `_preamble.md` (or paste into the Mode-A prompt) when auditing a
watsonx.data / Presto-Trino + Iceberg + object-storage repo:

 - SQL that errors on Trino/Presto grammar (e.g. T-SQL/Postgres-isms: `MERGE ... WHEN NOT MATCHED BY
   SOURCE`, `GENERATED ALWAYS AS IDENTITY`, `CREATE INDEX`, `TOP n`, `SELECT INTO`).
 - Iceberg DDL that assumes a format/spec the catalog does not run (e.g. `format-version` mismatch,
   hidden-partition transforms unsupported by the configured catalog).
 - A `catalog/*.properties` with duplicate keys, or a `connector.name` that does not match the
   deployed connector.
 - Object-store credentials (S3 `aws_access_key_id`/`aws_secret_access_key`, `AKIA…`) committed or
   baked into an image; a bucket without versioning/object-lock where WORM is claimed.
 - A `SELECT` that scans an un-partitioned/un-bucketed Iceberg table where the demo claims
   partition pruning (claim-vs-behaviour gap).
 - TLS disabled on the Trino coordinator / metastore where the docs claim encryption in transit.
 - A coordinator/worker `config.properties` whose `discovery.uri` / `http-server.http.port` cannot
   form a cluster under the compose topology (the engine never goes ready).
