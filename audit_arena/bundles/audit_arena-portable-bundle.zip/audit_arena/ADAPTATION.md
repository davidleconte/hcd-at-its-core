# ADAPTATION — retargeting the arena to a new IBM Data product

Everything domain-specific is **data in the active contract**. You do not edit `bin/arena.py`.
This guide covers the contract schema, the declarative check vocabulary, and a worked walkthrough of
the shipped **watsonx.data** starter profile.

---

## 1. The five things a profile defines

A profile is a directory `audit_arena/profiles/<name>/` containing:

| File | Purpose |
|---|---|
| `contract.v1.json` | **the** profile — dimensions, invariants, Oracle battery, cosmetics, `meta.content_sha256` |
| `reference_facts.json` | the version-fact denylist (an offline invariant fails if any fact drifts out of the docs) |
| `preamble.snippet.md` *(optional)* | product-specific forbidden patterns to paste into the LLM tribunal preamble |

Plus, in `contract.meta`, five cosmetic/behaviour knobs:

```jsonc
"meta": {
  "contract_version": "0.1.0",          // strict semver (no -suffix)
  "effective_date":   "2026-06-29",
  "project":          "watsonx-data",   // slug
  "title":            "watsonx.data audit arena",            // dashboard <title> + header
  "subtitle":         "Presto/Trino · Iceberg · object storage",
  "domain_lens":      "Lakehouse engineer (Trino/Iceberg)",  // the Judge's 2nd lens label
  "harness_paths":    [],               // extra paths a verify-fix patch may NOT touch (besides audit_arena/, tests/)
  "test_cmd":         "python3 -m pytest tests/ -q",         // used by verify-fix battery
  "reference_facts_ref": "audit_arena/profiles/watsonx-data/reference_facts.json",
  "content_sha256":   "…"               // STAMPED — see §4. Do not hand-edit.
}
```

> The engine still reads the legacy default slot `audit_arena/contract/contract.v1.json`. To activate
> a profile: `cp audit_arena/profiles/<name>/contract.v1.json audit_arena/contract/contract.v1.json`
> (or run with `ARENA_PROFILE=<name>` / `ARENA_CONTRACT=<path>`).

---

## 2. Invariants (the Definition-of-Done)

Each invariant is one falsifiable claim with a runnable command. Shape:

```jsonc
{ "id": "WXD-I1", "dim": "D1", "statement": "Iceberg round-trip executes on Trino",
  "mode": "offline" | "live",
  "offline_cmd": "…",     // mode:offline — exit 0 = PASS, 1 = FAIL, 2 = skip/unavailable
  "live_cmd":    "…",     // mode:live — run when the system is up
  "proxy_cmd":   "…" }    // mode:live — run when it is NOT up; may DEMOTE to FAIL (broken wiring)
                          //   but never CONFIRM (caps at DEFERRED). Burden on the artefact.
```

- `mode:offline` → needs only `offline_cmd`.
- `mode:live` → needs `live_cmd` **and** `proxy_cmd`.
- `dim` must be one of the contract's declared `dimensions` ids.
- Exit-code convention: **0 = PASS, 1 = FAIL, 2 = skip** (tool absent / not applicable).

---

## 3. The Oracle battery (`contract.oracle`)

This is what made the original hardcoded; now it is data. Three keys:

```jsonc
"oracle": {
  "live_probe": "curl -sf http://localhost:8080/v1/info",   // exit 0 == system up; null = no live tier
  "offline_checks": [ <check>, … ],   // always run
  "live_checks":    [ <check>, … ]    // run only when live_probe exits 0; else DEFERRED
}
```

A `<check>`:

```jsonc
{ "name": "Iceberg round-trip SQL executes",   // shown on the dashboard
  "dimension": "D1",
  "cmd": "…",                       // a shell command, OR:
  "cmd_from_invariant": "WXD-I1",   // …reuse an invariant's command (single source of truth, no drift)
  "ok": "exit0",                    // the pass predicate — see vocabulary below
  "detail": "last_line",            // optional — what to show in the detail column
  "timeout": 900,                   // optional, seconds (default 300)
  "deferred_hint": "start Trino first" }  // optional — shown when a live check defers
```

### `ok` predicate vocabulary

| `ok` value | passes when |
|---|---|
| `"exit0"` *(default)* | exit code == 0 |
| `"exit_nonzero"` | exit code != 0 |
| `{"exit": N}` | exit code == N |
| `{"contains": "s"}` | `s` appears in stdout+stderr |
| `{"contains_any": ["a","b"]}` | any listed string appears |
| `{"not_contains": "s"}` | `s` does **not** appear |
| `{"equals": "s"}` | trimmed output == `s` |
| `{"regex": "pat"}` | `pat` matches output |

### `detail` vocabulary

`null`/`"none"` (default, empty) · `"strip"` (trimmed output) · `"last_line"` · `{"line_contains": "s"}`
(first output line containing `s`).

---

## 4. Stamp the content hash (required)

`bin/arena.py contract` verifies `meta.content_sha256` over the contract body (everything except
`meta`). After ANY edit, re-stamp it or the gate refuses the contract:

```bash
python3 - <<'PY'
import hashlib, json
p = "audit_arena/profiles/watsonx-data/contract.v1.json"
c = json.load(open(p))
body = {k: v for k, v in c.items() if k != "meta"}
c["meta"]["content_sha256"] = hashlib.sha256(
    json.dumps(body, sort_keys=True, separators=(",", ":")).encode()).hexdigest()
json.dump(c, open(p, "w"), indent=2, ensure_ascii=False); open(p, "a").write("\n")
print("stamped", c["meta"]["content_sha256"][:12])
PY
python3 audit_arena/bin/arena.py contract        # -> CONTRACT OK … (verified)
```

(The generator `gen_profiles.py` that built the shipped profiles does this for you — keep editing it
and re-running if you prefer authoring contracts as Python dicts.)

---

## 5. Worked walkthrough — the watsonx.data starter

`profiles/watsonx-data/` is a **realistic starter**, not a finished profile. Every check is a *shape*
you point at your deployment. The `TODO` comments in the contract flag the spots. To finish it:

1. **`live_probe`** — set to your Trino/Presto health endpoint (`/v1/info` is standard) or a
   `trino --execute "SELECT 1"`. Edit host/port to your compose mapping.
2. **WXD-I1 (Iceberg round-trip)** — set `--server` and the `--catalog` name to your Iceberg catalog;
   adjust the schema/table names. The `proxy_cmd` greps for SQL that is invalid on Trino — extend the
   denylist with the dialect-isms your team tends to paste in (`MERGE … WHEN NOT MATCHED BY SOURCE`,
   `GENERATED ALWAYS AS IDENTITY`, `CREATE INDEX`, `SELECT … INTO`).
3. **WXD-I2 (object-store WORM)** — point the `mc`/`aws s3api` call at your bucket; the `proxy_cmd`
   greps your compose/config for `object-lock`/`versioning enabled`.
4. **WXD-I3 (catalog `.properties` dup-keys)** — the shipped check globs `config/**/*.properties`;
   adjust the glob if your catalogs live elsewhere.
5. **WXD-I4 / WXD-I7 + `reference_facts.json`** — replace the placeholder facts (`Trino 4`, `Iceberg`,
   `format-version 2`) with the exact version strings your docs pin. I7 fails if any drifts away.
6. **WXD-I5 (no secrets)** — already strong (S3 keys, `AKIA…`, private keys); usually no edit needed.
7. **`preamble.snippet.md`** — extend the product-specific forbidden patterns for your reviewers.

Then stamp (§4), validate, and run the pipeline:

```bash
ARENA_PROFILE=watsonx-data python3 audit_arena/bin/arena.py contract
ARENA_PROFILE=watsonx-data python3 audit_arena/bin/arena.py oracle
ARENA_PROFILE=watsonx-data python3 audit_arena/bin/arena.py invariants
ARENA_PROFILE=watsonx-data python3 audit_arena/bin/arena.py gate
```

### Mapping the six dimensions to watsonx.data

| Dim | HCD (origin) | watsonx.data (starter) |
|---|---|---|
| D1 correctness | Cassandra CQL / Part 11 DDM | Trino SQL + Iceberg DDL/DML; engine/format version facts |
| D2 config | `cassandra.yaml` + secure fragment merge | catalog `.properties`, coordinator/worker `config.properties`, compose merge |
| D3 scripts | `demo-entropy.sh` syntax/lint/score | deploy/demo scripts syntax + lint |
| D4 tests/CI | pytest + 94-module scorecard | pytest + CI gate |
| D5 docs | module-count single-source-of-truth | version/count single-source-of-truth |
| D6 security | secure cluster forms; cert/secret hygiene | object-store WORM/versioning; TLS; no S3 keys committed |

---

## 6. Other IBM Data targets (sketch)

The same recipe retargets to **Db2 / Db2 Warehouse** (Oracle checks via `db2` CLP + SQL probes;
`db2set`/`dbm cfg` config), **Cloud Pak for Data** (`oc`/`kubectl` + operator CRs + Helm/YAML
validation + RBAC/NetworkPolicy), **Netezza**, **IBM Storage Ceph**, etc. Copy `profiles/_template/`,
fill the dimensions/invariants/oracle, pin the version facts, stamp, validate. `WXD-I5`-style
secrets-hygiene and the dup-key/config-merge checks transfer almost verbatim.
