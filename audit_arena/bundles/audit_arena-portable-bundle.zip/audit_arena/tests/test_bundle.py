"""Standalone self-tests for the portable audit_arena engine.

Offline, no target system, fast. Proves: every shipped profile validates; the content hash is
self-consistent; the declarative check vocabulary works; the Oracle battery is contract-driven
(incl. cmd_from_invariant); the gate blocks on FAIL but not on DEFERRED; and llm.sh egress-gating
(the bash-3.2 source-guard regression) holds.

Run:  python3 -m pytest audit_arena/tests/ -q
"""
import hashlib
import importlib
import json
import os
import subprocess
import sys

ARENA = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))   # …/audit_arena
BIN = os.path.join(ARENA, "bin")
ARENA_PY = os.path.join(BIN, "arena.py")
PROFILES = os.path.join(ARENA, "profiles")
ALL_PROFILES = ["hcd", "watsonx-data", "_template"]


def _arena(env_extra=None):
    """Load (or reload) arena.py with optional env (ARENA_CONTRACT/ARENA_PROFILE) applied."""
    for k in ("ARENA_CONTRACT", "ARENA_PROFILE"):
        os.environ.pop(k, None)
    for k, v in (env_extra or {}).items():
        os.environ[k] = v
    if BIN not in sys.path:
        sys.path.insert(0, BIN)
    import arena
    return importlib.reload(arena)


# ─── profiles validate ─────────────────────────────────────────────────────────────────────────
def test_all_shipped_profiles_validate():
    for prof in ALL_PROFILES:
        r = subprocess.run([sys.executable, ARENA_PY, "contract"],
                           env=dict(os.environ, ARENA_PROFILE=prof),
                           capture_output=True, text=True)
        assert r.returncode == 0, f"{prof}: {r.stdout}{r.stderr}"
        assert "CONTRACT OK" in r.stdout and "verified" in r.stdout, f"{prof}: {r.stdout}"


def test_content_sha256_self_consistent():
    for prof in ALL_PROFILES:
        c = json.load(open(os.path.join(PROFILES, prof, "contract.v1.json")))
        body = {k: v for k, v in c.items() if k != "meta"}
        want = hashlib.sha256(json.dumps(body, sort_keys=True, separators=(",", ":")).encode()).hexdigest()
        assert c["meta"]["content_sha256"] == want, f"{prof}: stamp drift"


def test_every_invariant_well_formed():
    for prof in ALL_PROFILES:
        c = json.load(open(os.path.join(PROFILES, prof, "contract.v1.json")))
        dims = {d["id"] for d in c["dimensions"]}
        for inv in c["invariants"]:
            assert {"id", "dim", "statement", "mode"} <= set(inv)
            assert inv["dim"] in dims
            assert inv["mode"] in ("offline", "live")
            if inv["mode"] == "offline":
                assert inv.get("offline_cmd")
            else:
                assert inv.get("live_cmd") and inv.get("proxy_cmd")


# ─── declarative check vocabulary ────────────────────────────────────────────────────────────────
def test_eval_ok_vocabulary():
    a = _arena()
    assert a._eval_ok("exit0", 0, "") is True
    assert a._eval_ok("exit0", 1, "") is False
    assert a._eval_ok("exit_nonzero", 1, "") is True
    assert a._eval_ok({"exit": 2}, 2, "") is True
    assert a._eval_ok({"contains": "Score:  100%"}, 0, "Score:  100%") is True
    assert a._eval_ok({"contains_any": ["x", "UN"]}, 0, "6 UN nodes") is True
    assert a._eval_ok({"not_contains": "FAIL"}, 0, "all good") is True
    assert a._eval_ok({"equals": "6"}, 0, " 6 \n") is True
    assert a._eval_ok({"regex": r"\d+\.\d+"}, 0, "Cassandra 5.0.7") is True


def test_detail_vocabulary():
    a = _arena()
    assert a._detail(None, 0, "x") == ""
    assert a._detail("strip", 0, "  hi \n") == "hi"
    assert a._detail("last_line", 0, "a\nb\nc\n") == "c"
    assert a._detail({"line_contains": "ver"}, 0, "foo\nrelease_version 5.0\nbar") == "release_version 5.0"


# ─── Oracle is contract-driven (incl. cmd_from_invariant) + gate semantics ───────────────────────
def _write_contract(path, offline_checks, invariants=None):
    c = {
        "meta": {"contract_version": "1.0.0", "effective_date": "2026-01-01", "project": "t",
                 "title": "t arena", "reference_facts_ref": ""},
        "dimensions": [{"id": "D1", "name": "x", "scope": "x"}],
        "severity_scale": {"LOW": "#000"},
        "invariants": invariants or [],
        "oracle": {"live_probe": None, "offline_checks": offline_checks, "live_checks": []},
    }
    body = {k: v for k, v in c.items() if k != "meta"}
    c["meta"]["content_sha256"] = hashlib.sha256(
        json.dumps(body, sort_keys=True, separators=(",", ":")).encode()).hexdigest()
    json.dump(c, open(path, "w"))
    return c


def test_oracle_runs_contract_battery_and_cmd_from_invariant(tmp_path):
    cpath = str(tmp_path / "c.json")
    _write_contract(
        cpath,
        offline_checks=[
            {"name": "passes", "dimension": "D1", "cmd": "true", "ok": "exit0"},
            {"name": "fails", "dimension": "D1", "cmd": "false", "ok": "exit0"},
            {"name": "reused", "dimension": "D1", "cmd_from_invariant": "T-I1", "ok": "exit0"},
        ],
        invariants=[{"id": "T-I1", "dim": "D1", "statement": "s", "mode": "offline", "offline_cmd": "true"}],
    )
    a = _arena({"ARENA_CONTRACT": cpath})
    try:
        a.oracle("99")
        out = json.load(open(os.path.join(a.STATE, "oracle_r99.json")))
        by = {c["check"]: c["status"] for c in out["checks"]}
        assert by == {"passes": "PASS", "fails": "FAIL", "reused": "PASS"}, by
    finally:
        p = os.path.join(a.STATE, "oracle_r99.json")
        os.path.exists(p) and os.remove(p)


def test_gate_blocks_on_fail_not_on_deferred(tmp_path):
    cpath = str(tmp_path / "c.json")
    _write_contract(cpath, offline_checks=[{"name": "ok", "dimension": "D1", "cmd": "true", "ok": "exit0"}])
    env = dict(os.environ, ARENA_CONTRACT=cpath)
    subprocess.run([sys.executable, ARENA_PY, "oracle", "98"], env=env, capture_output=True, text=True)
    subprocess.run([sys.executable, ARENA_PY, "invariants", "98"], env=env, capture_output=True, text=True)
    g = subprocess.run([sys.executable, ARENA_PY, "gate"], env=env, capture_output=True, text=True)
    a = _arena({"ARENA_CONTRACT": cpath})
    for r in ("98",):
        for f in (f"oracle_r{r}.json", f"invariants_r{r}.json"):
            p = os.path.join(a.STATE, f)
            os.path.exists(p) and os.remove(p)
    assert g.returncode == 0, f"gate should pass with no FAIL: {g.stdout}{g.stderr}"


# ─── llm.sh egress-gating (bash-3.2 source-guard regression) ─────────────────────────────────────
def test_llm_sh_egress_gated_without_optin(tmp_path):
    """No ARENA_MODE_B → exit 2 (abstain). Hermetic: HOME→empty dir must NOT abort the script under
    `set -e` on bash 3.2 (the missing ~/.secrets.env source-guard bug)."""
    llm = os.path.join(BIN, "llm.sh")
    pf = tmp_path / "p.md"
    pf.write_text("test")
    env = dict(os.environ, HOME=str(tmp_path), ARENA_PROVIDER="anthropic", ANTHROPIC_API_KEY="")
    env.pop("ARENA_MODE_B", None)
    r = subprocess.run(["bash", llm, "judge", str(pf)], capture_output=True, text=True, env=env)
    assert r.returncode == 2, f"expected egress-gated exit 2, got {r.returncode}: {r.stdout}{r.stderr}"


def test_llm_sh_key_gated_exit2(tmp_path):
    """ARENA_MODE_B=1 but no key, empty HOME → exit 2 (key-gated abstain), NOT 1 (would be the
    bash-3.2 source-abort, or an 'unknown provider')."""
    llm = os.path.join(BIN, "llm.sh")
    pf = tmp_path / "p.md"
    pf.write_text("test")
    env = dict(os.environ, HOME=str(tmp_path), ARENA_MODE_B="1",
               ARENA_PROVIDER="anthropic", ANTHROPIC_API_KEY="")
    r = subprocess.run(["bash", llm, "judge", str(pf)], capture_output=True, text=True, env=env)
    assert r.returncode == 2, f"expected key-gated exit 2, got {r.returncode}: {r.stdout}{r.stderr}"
